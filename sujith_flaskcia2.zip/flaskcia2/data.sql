CREATE DATABASE flask_login;
USE flask_login;



CREATE TABLE Accounts ( 
username varchar(50) NOT NULL,
password varchar(255) NOT NULL
);

INSERT INTO Accounts VALUES ("Sujith1","Sujith10"),("Saaketh1","Saaketh10"),("Test","Test123");
SELECT *FROM Accounts;