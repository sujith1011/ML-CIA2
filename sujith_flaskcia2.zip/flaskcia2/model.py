import pandas as pd
import numpy as np
import pickle

data = pd.read_csv("‪C:\Users\saake\Downloads\top_comp_2223.csv")
data.head()

#%%
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder

le = LabelEncoder()
data["Company"] = le.fit_transform(data["Company"])
data = data.drop(columns="Industry")
data.head()

print(le.classes_)
# %%
data.head()
X = data.iloc[:,:-1].values
y = data.iloc[:,-1].values
model = RandomForestClassifier()
model.fit(X, y)

with open('model.pkl', 'wb') as f:
    pickle.dump(model, f)

